using UnityEngine;

// Lives on the target prefab root. Collider on a child is the scoring zone;
// a Rigidbody is not needed here because the ball is the moving body.
public class Target : MonoBehaviour
{
    [SerializeField] int points = 10;

    // Called by ScoreZone when a ball enters the trigger.
    public void Hit(GameObject ball)
    {
        GameManager.Instance.AddScore(points);
        Destroy(ball);
    }
}
