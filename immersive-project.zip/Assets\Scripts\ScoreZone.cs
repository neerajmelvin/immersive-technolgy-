using UnityEngine;

// Trigger collider on the target; OnTriggerEnter only fires on the object that owns the collider.
[RequireComponent(typeof(Collider))]
public class ScoreZone : MonoBehaviour
{
    Target target;

    void Awake() => target = GetComponentInParent<Target>();

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Ball")) target.Hit(other.gameObject);
    }
}
