using TMPro;
using UnityEditor;
using UnityEditor.Events;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.ARFoundation;

// Menu: AR Ball Toss > Create Gameplay Objects
// Run after the scene already has an AR Session and XR Origin (Mobile AR).
public static class BallTossSetup
{
    const string PrefabDir = "Assets/Prefabs";

    [MenuItem("AR Ball Toss/Create Gameplay Objects")]
    static void Create()
    {
        var raycast = Object.FindFirstObjectByType<ARRaycastManager>();
        var planes = Object.FindFirstObjectByType<ARPlaneManager>();
        if (!raycast || !planes)
        {
            Debug.LogError("Add an XR Origin (Mobile AR) with ARRaycastManager and ARPlaneManager first.");
            return;
        }

        EnsureTag("Ball");
        System.IO.Directory.CreateDirectory(PrefabDir);
        var ballPrefab = MakeBallPrefab();
        var targetPrefab = MakeTargetPrefab();

        var canvasGo = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvasGo.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1080, 1920);

        var score = MakeText(canvasGo.transform, "ScoreText", new Vector2(0, -80), 64, new Vector2(0.5f, 1));
        var hint = MakeText(canvasGo.transform, "HintText", new Vector2(0, 200), 44, new Vector2(0.5f, 0));

        var gmGo = new GameObject("GameManager");
        var gm = gmGo.AddComponent<GameManager>();
        SetRef(gm, "scoreText", score);
        SetRef(gm, "hintText", hint);

        var placer = gmGo.AddComponent<TargetPlacer>();
        SetRef(placer, "raycastManager", raycast);
        SetRef(placer, "planeManager", planes);
        SetRef(placer, "targetPrefab", targetPrefab);

        var launcher = gmGo.AddComponent<BallLauncher>();
        SetRef(launcher, "ballPrefab", ballPrefab.GetComponent<Rigidbody>());

        MakeRepositionButton(canvasGo.transform, placer);

        // The GameManager object must exist in a scene that has an EventSystem for the button to work.
        if (!Object.FindFirstObjectByType<UnityEngine.EventSystems.EventSystem>())
            new GameObject("EventSystem", typeof(UnityEngine.EventSystems.EventSystem),
                typeof(UnityEngine.InputSystem.UI.InputSystemUIInputModule));

        Debug.Log("AR Ball Toss gameplay objects created. Save the scene.");
    }

    static GameObject MakeBallPrefab()
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = "Ball";
        go.tag = "Ball";
        go.transform.localScale = Vector3.one * 0.08f;
        var rb = go.AddComponent<Rigidbody>();
        rb.mass = 0.1f;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        go.GetComponent<Renderer>().sharedMaterial = ColorMaterial(Color.red, "Ball");
        return Save(go, "Ball");
    }

    // A pad on the floor, a backboard, and an invisible trigger box above the pad as the scoring zone.
    static GameObject MakeTargetPrefab()
    {
        var root = new GameObject("Target");
        root.AddComponent<Target>();

        var pad = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        pad.name = "Pad";
        pad.transform.SetParent(root.transform, false);
        pad.transform.localScale = new Vector3(0.4f, 0.005f, 0.4f);
        pad.GetComponent<Renderer>().sharedMaterial = ColorMaterial(Color.yellow, "Pad");

        var wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
        wall.name = "Backboard";
        wall.transform.SetParent(root.transform, false);
        wall.transform.localPosition = new Vector3(0, 0.25f, 0.25f);
        wall.transform.localScale = new Vector3(0.5f, 0.5f, 0.02f);
        wall.GetComponent<Renderer>().sharedMaterial = ColorMaterial(Color.cyan, "Backboard");

        var zone = new GameObject("ScoreZone");
        zone.transform.SetParent(root.transform, false);
        zone.transform.localPosition = new Vector3(0, 0.15f, 0);
        var box = zone.AddComponent<BoxCollider>();
        box.isTrigger = true;
        box.size = new Vector3(0.3f, 0.3f, 0.3f);
        // A trigger needs a Rigidbody on one side of the pair; the ball has one.
        zone.AddComponent<ScoreZone>();

        return Save(root, "Target");
    }

    static Material ColorMaterial(Color color, string name)
    {
        var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
        var mat = new Material(shader) { color = color };
        AssetDatabase.CreateAsset(mat, $"{PrefabDir}/{name}.mat");
        return mat;
    }

    static GameObject Save(GameObject go, string name)
    {
        var prefab = PrefabUtility.SaveAsPrefabAsset(go, $"{PrefabDir}/{name}.prefab");
        Object.DestroyImmediate(go);
        return prefab;
    }

    static TMP_Text MakeText(Transform parent, string name, Vector2 pos, float size, Vector2 anchor)
    {
        var go = new GameObject(name, typeof(TextMeshProUGUI));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = rt.pivot = anchor;
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(900, 120);
        var t = go.GetComponent<TextMeshProUGUI>();
        t.fontSize = size;
        t.alignment = TextAlignmentOptions.Center;
        t.color = Color.white;
        return t;
    }

    static void MakeRepositionButton(Transform parent, TargetPlacer placer)
    {
        var go = new GameObject("RepositionButton", typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(1, 1);
        rt.anchoredPosition = new Vector2(-40, -40);
        rt.sizeDelta = new Vector2(260, 100);
        UnityEventTools.AddPersistentListener(go.GetComponent<Button>().onClick, placer.Reposition);
        var label = MakeText(go.transform, "Label", Vector2.zero, 36, new Vector2(0.5f, 0.5f));
        label.text = "Reposition";
        label.color = Color.black;
    }

    static void SetRef(Object target, string field, Object value)
    {
        var so = new SerializedObject(target);
        so.FindProperty(field).objectReferenceValue = value;
        so.ApplyModifiedPropertiesWithoutUndo();
    }

    static void EnsureTag(string tag)
    {
        var tm = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset")[0]);
        var tags = tm.FindProperty("tags");
        for (int i = 0; i < tags.arraySize; i++)
            if (tags.GetArrayElementAtIndex(i).stringValue == tag) return;
        tags.InsertArrayElementAtIndex(tags.arraySize);
        tags.GetArrayElementAtIndex(tags.arraySize - 1).stringValue = tag;
        tm.ApplyModifiedProperties();
    }
}
