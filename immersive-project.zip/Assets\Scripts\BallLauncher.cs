using UnityEngine;
using UnityEngine.InputSystem.EnhancedTouch;
using Touch = UnityEngine.InputSystem.EnhancedTouch.Touch;

// Swipe on screen to throw a ball from the camera. Swipe speed sets throw strength.
public class BallLauncher : MonoBehaviour
{
    [SerializeField] Rigidbody ballPrefab;
    [SerializeField] float minSwipePixels = 80f;
    [SerializeField] float minSpeed = 2f;
    [SerializeField] float maxSpeed = 8f;
    [SerializeField] float upwardBias = 0.35f;
    [SerializeField] float ballLifetime = 6f;

    Vector2 startPos;
    float startTime;

    void OnEnable() => EnhancedTouchSupport.Enable();
    void OnDisable() => EnhancedTouchSupport.Disable();

    void Update()
    {
        if (!GameManager.Instance.TargetPlaced || Touch.activeTouches.Count == 0) return;

        var touch = Touch.activeTouches[0];
        switch (touch.phase)
        {
            case UnityEngine.InputSystem.TouchPhase.Began:
                startPos = touch.screenPosition;
                startTime = Time.time;
                break;
            case UnityEngine.InputSystem.TouchPhase.Ended:
                Throw(touch.screenPosition - startPos, Time.time - startTime);
                break;
        }
    }

    void Throw(Vector2 swipe, float duration)
    {
        if (swipe.y <= 0 || swipe.magnitude < minSwipePixels) return;

        var cam = Camera.main.transform;
        float pixelsPerSecond = swipe.magnitude / Mathf.Max(duration, 0.05f);
        float speed = Mathf.Lerp(minSpeed, maxSpeed, Mathf.InverseLerp(500f, 4000f, pixelsPerSecond));

        // Horizontal swipe steers left/right; the upward bias gives a natural arc.
        var dir = cam.forward + cam.up * upwardBias + cam.right * (swipe.x / Screen.width);
        var spawnPos = cam.position + cam.forward * 0.3f - cam.up * 0.1f;

        var ball = Instantiate(ballPrefab, spawnPos, Quaternion.identity);
        ball.linearVelocity = dir.normalized * speed;
        Destroy(ball.gameObject, ballLifetime);
    }
}
