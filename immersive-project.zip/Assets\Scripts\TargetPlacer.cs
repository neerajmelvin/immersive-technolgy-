using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem.EnhancedTouch;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using Touch = UnityEngine.InputSystem.EnhancedTouch.Touch;

// Tap on a detected plane to place the target there.
public class TargetPlacer : MonoBehaviour
{
    [SerializeField] ARRaycastManager raycastManager;
    [SerializeField] ARPlaneManager planeManager;
    [SerializeField] GameObject targetPrefab;

    static readonly List<ARRaycastHit> hits = new();
    GameObject target;

    void OnEnable()
    {
        EnhancedTouchSupport.Enable();
#if UNITY_EDITOR
        TouchSimulation.Enable(); // mouse acts as touch in the editor
#endif
    }

    void OnDisable()
    {
#if UNITY_EDITOR
        TouchSimulation.Disable();
#endif
        EnhancedTouchSupport.Disable();
    }

    void Update()
    {
        var gm = GameManager.Instance;
        if (gm.TargetPlaced || Touch.activeTouches.Count == 0) return;

        var touch = Touch.activeTouches[0];
        if (touch.phase != UnityEngine.InputSystem.TouchPhase.Ended) return;

        Pose pose;
        if (raycastManager.Raycast(touch.screenPosition, hits, TrackableType.PlaneWithinPolygon))
            pose = hits[0].pose;
#if UNITY_EDITOR
        else if (!TryEditorFloorHit(touch.screenPosition, out pose)) return;
#else
        else return;
#endif

        if (target) Destroy(target);
        target = Instantiate(targetPrefab, pose.position, Quaternion.identity);
        FaceCamera(target.transform);

        gm.OnTargetPlaced();
        SetPlanesVisible(false);
    }

    // Called by the Reposition UI button.
    public void Reposition()
    {
        if (target) Destroy(target);
        GameManager.Instance.ResetTarget();
        SetPlanesVisible(true);
    }

#if UNITY_EDITOR
    // No real planes on a PC, so pretend the floor is 1.2 m below the camera.
    static bool TryEditorFloorHit(Vector2 screenPos, out Pose pose)
    {
        var cam = Camera.main;
        var ray = cam.ScreenPointToRay(screenPos);
        var floor = new Plane(Vector3.up, new Vector3(0, cam.transform.position.y - 1.2f, 0));
        pose = default;
        if (!floor.Raycast(ray, out float dist)) return false;
        pose = new Pose(ray.GetPoint(dist), Quaternion.identity);
        return true;
    }
#endif

    void FaceCamera(Transform t)
    {
        // The target's local +Z points away from the thrower, so look away from the camera.
        var away = t.position - Camera.main.transform.position;
        away.y = 0;
        if (away.sqrMagnitude > 0.001f) t.rotation = Quaternion.LookRotation(away);
    }

    void SetPlanesVisible(bool visible)
    {
        planeManager.enabled = visible;
        foreach (var plane in planeManager.trackables) plane.gameObject.SetActive(visible);
    }
}
