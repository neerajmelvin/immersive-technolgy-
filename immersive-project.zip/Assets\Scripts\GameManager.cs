using TMPro;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [SerializeField] TMP_Text scoreText;
    [SerializeField] TMP_Text hintText;

    public int Score { get; private set; }
    public bool TargetPlaced { get; private set; }

    void Awake()
    {
        Instance = this;
        SetHint("Move your phone to find a flat surface, then tap to place the target");
        UpdateScore();
    }

    public void OnTargetPlaced()
    {
        TargetPlaced = true;
        SetHint("Swipe up to throw the ball");
    }

    public void ResetTarget()
    {
        TargetPlaced = false;
        SetHint("Tap a surface to place the target");
    }

    public void AddScore(int points)
    {
        Score += points;
        UpdateScore();
    }

    public void SetHint(string text)
    {
        if (hintText) hintText.text = text;
    }

    void UpdateScore()
    {
        if (scoreText) scoreText.text = $"Score: {Score}";
    }
}
