# AR Ball Toss (WebXR)

Single file: `index.html` (three.js loaded from a CDN, so internet is needed).

## Run on PC (on-screen mode)
    python -m http.server 8080 --directory D:\immersive\webxr
Open http://localhost:8080, click "Play on screen". Click to place the target, drag upward to throw.

## Run on the OnePlus 7 Pro over USB
1. Phone: Settings > About device, tap Build number 7 times. Settings > System > Developer options > USB debugging on.
2. Phone: install/update "Google Play Services for AR" from the Play Store. Use Chrome.
3. PC: install Android platform-tools (https://developer.android.com/tools/releases/platform-tools), unzip, then:
       adb devices                      (phone must show "device"; accept the prompt on the phone)
       adb reverse tcp:8080 tcp:8080
4. Keep the server from the PC step running. In Chrome on the phone open http://localhost:8080 and tap "Start AR".
   (localhost counts as a secure context, so WebXR works without HTTPS.)

To use it without USB later, host the folder on GitHub Pages or any HTTPS host.

## Play
Move the phone slowly until the green ring appears on a surface, tap to place the target, swipe up to throw. Ball must land in the green wireframe box to score 10. Reposition button moves the target.
